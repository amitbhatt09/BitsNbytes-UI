export interface LoginResponse{
   
    email: string;
    roles: string[];
}

export interface User{
    email:string;
    roles:string[];
}