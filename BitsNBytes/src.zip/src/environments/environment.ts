export const environment = {
     apiBaseUrl : 'https://prod.BitNBytes.com',
     environmentName : 'production'
};
