export const environment = {
     apiBaseUrl : 'https://localhost:7255',
     environmentName : 'development'
};
